package com.example.worktimer;

import android.content.Context;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView timerText;
    private TextView modeText;
    private TextView nextModeText;
    private Button startButton;
    private Button resetButton;

    private EditText workTimeInput;
    private EditText shortBreakTimeInput;
    private EditText longBreakTimeInput;

    private CountDownTimer countDownTimer;
    private boolean isTimerRunning = false;
    private long timeLeftInMillis = 0; // Оставшееся время
    private int pomodoroCount = 0; // Счетчик циклов Помидоро
    private boolean isBreakTime = false; // Флаг, указывающий на перерыв

    // Время работы, короткого и длинного отдыха по умолчанию
    private static long workTimeInMillis = 1500000; // 25 минут работы
    private static long shortBreakTimeInMillis = 300000; // 5 минут отдыха
    private static long longBreakTimeInMillis = 1200000; // 20 минут отдыха

    private MediaPlayer mediaPlayer;
    private Vibrator vibrator;

    private Handler handler = new Handler();
    private boolean resetConfirmed = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        timerText = findViewById(R.id.timer_text);
        modeText = findViewById(R.id.mode_text);
        nextModeText = findViewById(R.id.next_mode_text);
        startButton = findViewById(R.id.start_button);
        resetButton = findViewById(R.id.reset_button);

        workTimeInput = findViewById(R.id.work_time_input);
        shortBreakTimeInput = findViewById(R.id.short_break_time_input);
        longBreakTimeInput = findViewById(R.id.long_break_time_input);

        // Инициализация звукового оповещения
        mediaPlayer = MediaPlayer.create(this, R.raw.notification_sound);

        // Инициализация вибрации
        vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);

        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isTimerRunning) {
                    pauseTimer();
                } else {
                    startTimer();
                }
            }
        });

        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Для того чтобы сбросить таймер нажмите и задержите", Toast.LENGTH_LONG).show();
            }
        });

        resetButton.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                resetConfirmed = true;
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (resetConfirmed) {
                            resetTimer();
                        }
                    }
                }, 1500); // 1.5 секунды задержки
                return true;
            }
        });

        resetButton.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_UP) {
                    resetConfirmed = false;
                }
                return false;
            }
        });

        updateTimerText();
        updateModeText();
        updateNextModeText();
    }

    // Метод для запуска таймера
    private void startTimer() {
        long startTimeInMillis;

        if (isBreakTime) {
            if (pomodoroCount % 4 == 0) {
                startTimeInMillis = longBreakTimeInMillis;
                modeText.setText("Длинный перерыв");
            } else {
                startTimeInMillis = shortBreakTimeInMillis;
                modeText.setText("Короткий перерыв");
            }
        } else {
            startTimeInMillis = workTimeInMillis;
            modeText.setText("Работа");
        }

        if (timeLeftInMillis == 0) {
            timeLeftInMillis = startTimeInMillis;
        }

        countDownTimer = new CountDownTimer(timeLeftInMillis, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                timeLeftInMillis = millisUntilFinished;
                updateTimerText();
            }

            @Override
            public void onFinish() {
                // Запуск звукового оповещения и вибрации при завершении таймера
                mediaPlayer.start();
                vibrator.vibrate(VibrationEffect.createOneShot(500, VibrationEffect.DEFAULT_AMPLITUDE));

                if (isBreakTime) {
                    isBreakTime = false;
                    startButton.setText("Начать работу");
                } else {
                    isBreakTime = true;
                    pomodoroCount++;
                    startButton.setText("Начать перерыв");
                }
                timeLeftInMillis = 0;
                updateTimerText();
                updateModeText();
                updateNextModeText();
                startTimer();
            }
        }.start();

        isTimerRunning = true;
        startButton.setText("Пауза");
    }

    // Метод для паузы таймера
    private void pauseTimer() {
        countDownTimer.cancel();
        isTimerRunning = false;
        startButton.setText("Старт");
    }

    // Метод для сброса таймера
    private void resetTimer() {
        // Получение значений времени из полей ввода при сбросе
        workTimeInMillis = Integer.parseInt(workTimeInput.getText().toString()) * 60000;
        shortBreakTimeInMillis = Integer.parseInt(shortBreakTimeInput.getText().toString()) * 60000;
        longBreakTimeInMillis = Integer.parseInt(longBreakTimeInput.getText().toString()) * 60000;

        timeLeftInMillis = workTimeInMillis; // Установить время работы
        pomodoroCount = 0; // Сбросить счетчик циклов Помидоро
        isBreakTime = false; // Сбросить флаг перерыва
        updateTimerText();
        updateModeText();
        updateNextModeText();

        // Если таймер запущен, остановить его
        if (isTimerRunning) {
            countDownTimer.cancel();
            isTimerRunning = false;
            startButton.setText("Старт");
        }
    }

    // Метод для обновления текста текущего режима (работа, короткий перерыв, длинный перерыв)
    private void updateModeText() {
        if (isBreakTime) {
            if (pomodoroCount % 4 == 0) {
                modeText.setText("Длинный перерыв");
            } else {
                modeText.setText("Короткий перерыв");
            }
        } else {
            modeText.setText("Работа");
        }
    }

    // Метод для обновления текста следующего режима
    private void updateNextModeText() {
        if (isBreakTime) {
            nextModeText.setText("Далее: Работа");
        } else {
            if (pomodoroCount % 4 == 3) {
                nextModeText.setText("Далее: Длинный перерыв");
            } else {
                nextModeText.setText("Далее: Короткий перерыв");
            }
        }
    }

    // Метод для обновления текста таймера
    private void updateTimerText() {
        int minutes = (int) (timeLeftInMillis / 1000) / 60;
        int seconds = (int) (timeLeftInMillis / 1000) % 60;
        String timeFormatted = String.format("%02d:%02d", minutes, seconds);
        timerText.setText(timeFormatted);
    }
}